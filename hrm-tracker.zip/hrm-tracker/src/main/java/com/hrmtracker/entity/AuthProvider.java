package com.hrmtracker.entity;

public enum AuthProvider {
    LOCAL,
    GOOGLE
}
