package com.hrmtracker.entity;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
}
